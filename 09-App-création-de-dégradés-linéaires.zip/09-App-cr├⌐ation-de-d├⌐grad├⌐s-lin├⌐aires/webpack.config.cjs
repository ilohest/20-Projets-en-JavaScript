const HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path');

module.exports = {
  mode: 'development',
  entry: './src/app.js', // Chemin vers ton fichier d'entrée principal
  output: {
    filename: 'bundle.js', // Le nom du fichier de sortie
    path: path.resolve(__dirname, 'dist'), // Le chemin du dossier de sortie
  },
  output: {
    filename: 'bundle.js', // Le nom du fichier de sortie
    path: path.resolve(__dirname, 'dist'), // Le chemin du dossier de sortie
  },
  devServer: {
    static: {
      directory: path.join(__dirname, 'dist'),
    },
   },
  resolve: {
  extensions: ['.js', '.json', '.jsx', '.ts'], // Ajoute d'autres extensions si nécessaire
  modules: ['node_modules'],
},
  plugins: [
    new HtmlWebpackPlugin({
      template: path.join(__dirname, 'src', 'index.html'), // Chemin vers ton fichier index.html
      filename: 'index.html' // Nom du fichier généré dans dist
    })
  ],
    module: {
    rules: [
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader']
      },
      // ... autres règles ...
    ]
  },
};
